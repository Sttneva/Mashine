public class BigCar {
    String name;
    int age;
    int weight;
    String color;

    public BigCar(String name, int age, int weight, String color) {
        this.name = name;
        this.age = age;
        this.weight = weight;
        this.color = color;
    }
}
